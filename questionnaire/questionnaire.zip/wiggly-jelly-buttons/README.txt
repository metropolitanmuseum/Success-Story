A Pen created at CodePen.io. You can find this one at https://codepen.io/piecdesmit/pen/OMYNZg.

 CSS3-only animation for a playful wiggly button active and hover states. 
Great fit for a game project or web UI for kids.
Inspired by http://bouncejs.com/