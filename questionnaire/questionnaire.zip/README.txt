A Pen created at CodePen.io. You can find this one at http://codepen.io/wilder_taype/pen/pNXwMW.

 Ripple animation on  input type radio and Checkbox . more info https://goo.gl/VoFJrw